"""Service A package init file."""
