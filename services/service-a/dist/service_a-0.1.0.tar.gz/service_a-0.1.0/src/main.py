def main():
    from service_a.server import serve
    serve()

if __name__ == "__main__":
    main()
